# Project Governance Workspace — Codex Cloud Implementation Pack

This repository-ready pack is designed for **Codex Cloud**.

## How to use

1. Create a new GitHub repository.
2. Copy all files from this pack into the repository root.
3. Open Codex Cloud on the repository.
4. Start with: `docs/codex/MASTER_CODEX_PROMPT.md`.
5. Execute tasks sequentially from `docs/tasks/`.

## Non-negotiable product constraints

- No backend.
- No database.
- No authentication.
- No server-side persistence.
- One `.pmgov` project file open at a time.
- All project data remains local to the user-controlled file.
- Browser app only.

## Recommended stack

- Next.js App Router
- TypeScript strict mode
- Tailwind CSS
- Zod for runtime schema validation
- React Hook Form or equivalent for forms
- Local file open/save through browser APIs
- Optional: Tiptap for rich text editor

## Build order

1. `TASK_01_REPO_SETUP.md`
2. `TASK_02_DATA_MODEL_AND_FILE_LIFECYCLE.md`
3. `TASK_03_APP_SHELL_AND_NAVIGATION.md`
4. `TASK_04_WORKSTREAMS_STAGES_MILESTONES.md`
5. `TASK_05_NOTEBOOK.md`
6. `TASK_06_GOVERNANCE_REGISTERS.md`
7. `TASK_07_DASHBOARD.md`
8. `TASK_08_REPORTING.md`
9. `TASK_09_QA_HARDENING.md`
